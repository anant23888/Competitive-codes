Alternate time optimal and sasaki are written in java and you have to insert value for every input
while odd even transposition is written in python and values are generated randomly 