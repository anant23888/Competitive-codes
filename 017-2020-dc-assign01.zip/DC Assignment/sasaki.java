import java.util.Scanner;

class pair {
    int first, second, area;
    int markedbefore, markedafter;
}

class UsingThread extends Thread {
    int i1, i2;

    UsingThread(int i1, int i2) {
        this.i1 = i1;
        this.i2 = i2;
    }
    public void send(pair p, int i2) {
        computation(p, i2);
    }
    public void computation(pair p, int i2) {
        if (p.second > sasaki.p[i2].first) {
            if (p.markedbefore == 1) {
                sasaki.p[i2].area -= 1;
            }
            if (sasaki.p[i2].markedbefore==1) {
                sasaki.p[i2].area += 1;
            }
            int temp = sasaki.p[i2].first;
            sasaki.p[i2].first = p.second;
            p.second = temp;
            int tempmarked = p.markedbefore;
            p.markedbefore = sasaki.p[i2].markedbefore;
            sasaki.p[i2].markedbefore = tempmarked;
        }
    }
    public void receive(pair p) {
        sasaki.p[i1] = p;
    }
    public void run() {
        try {

            send(sasaki.p[i1], i2);
        } catch (Exception e) {
            System.out.println("Exception is caught"+e);
        }
    }
}
public class sasaki{
    static int n=20;
    static pair []p=new pair[n];
    static int flg=0;
    public static void main(String[] args){
        int []arr=new int[n];
        try (Scanner sc = new Scanner(System.in)) 
        {
            System.out.println("Enter "+n+" values to perform sasaki algorithm using"+"<="+"...");
            for(int i=0;i<n;i++){
                arr[i]=sc.nextInt();
                p[i]=new pair();
                p[i].first=arr[i];
                p[i].second = arr[i];
                p[i].area = 0;
                p[i].markedbefore = 0;
                p[i].markedafter = 0;
            }
            p[0].area = -1;
            p[0].markedafter = 1;
            p[n - 1].markedbefore = 1; 
        }
        System.out.println("Round No. "+(0));
        for (int j = 0; j < n; j++) {
            String markedbefore="";
            String markesecond="";
            if(p[j].markedbefore==1)
                markedbefore="*";
            if(p[j].markedafter==1)
                markesecond="*";
            if (j == 0)
                System.out.print( p[j].second +markesecond +" area = " + p[j].area + " | ");
            else if (j == n - 1)
                System.out.println(p[j].first + markedbefore+" area = " + p[j].area + " | ");
            else
                System.out.print( p[j].first + markedbefore+"," + p[j].second + markesecond+"  area = " + p[j].area + " | ");
        }

        for (int i = 0; i < n - 1; i++) {
            flg = 0;
            UsingThread u[] = new UsingThread[n];
            for (int j = 0; j < n - 1; j++) {
                /*
                Creating a thread object between for communication
                between 2 nodes and running the thread.
                 */
                u[j] = new UsingThread(j, j + 1);
                u[j].start();
            }
            for (int j = 0; j < n - 1; j++) {
                try {
                    /*
                    Waiting for each thread to finish,inorder to complete the round
                     */
                    u[j].join();
                } catch (Exception e) {
                    System.out.println("Exception caught " + e);
                }
            }
            /*
            Further local computation inside the nodes
             */
            for (int j = 1; j < n - 1; j++) {
                if (p[j].first > p[j].second) {
                    int temp = p[j].first;
                    p[j].first = p[j].second;
                    p[j].second = temp;
                    temp = p[j].markedbefore;
                    p[j].markedbefore = p[j].markedafter;
                    p[j].markedafter = temp;
                }
            }
            /*
            Printing states of nodes after each round
             */
            System.out.println("Round No. " + (i + 1));
            for (int j = 0; j < n; j++) {
                String markedbefore="";
                String markesecond="";
                if(p[j].markedbefore==1)
                    markedbefore="*";
                if(p[j].markedafter==1)
                    markesecond="*";
                if (j==0)
                    System.out.print(p[j].second +markesecond +" area = " + p[j].area + " | ");
                else if (j==n - 1)
                    System.out.println(p[j].first + markedbefore+" area = " + p[j].area + " | ");
                else
                    System.out.print(p[j].first + markedbefore+" , " + p[j].second + markesecond+" area = " + p[j].area + " | ");
            }
        }
        System.out.println("Final Sorted array is...");
        for (int i = 0; i < n; i++) {
            if (i == 0)
                System.out.print(p[i].second + "|"); 
            else if (i == n - 1)
                System.out.println(p[i].first + "\n");       
            else if (p[i].area < 0)
                System.out.print(p[i].first+ " | ");
            else
                System.out.print(p[i].second+ " | ");
        }
    }
}