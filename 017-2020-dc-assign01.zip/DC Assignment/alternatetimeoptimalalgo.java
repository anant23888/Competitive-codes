import java.util.Scanner;

class pair{
    int val;
    int modval;
}
class UsingThread extends Thread{
    int i1,i2,i3;
    UsingThread(int i1,int i2,int i3){
        this.i1=i1;
        this.i2=i2;
        this.i3=i3;
    }
    public void send(int i1, int i2) {
        computation(i1, i2);
    }
    public void send(int i1, int i2, int i3) {
        computation(i1,i2,i3);
    }
    public void computation(int i1, int i2) {
        int min = Math.min(alternatetimeoptimalalgo.p[i1].val, alternatetimeoptimalalgo.p[i2].val);
        if (alternatetimeoptimalalgo.p[i1].val > alternatetimeoptimalalgo.p[i2].val)
            alternatetimeoptimalalgo.p[i2].val = alternatetimeoptimalalgo.p[i1].val;
        receive(i1, min);
    }
    public void receive(int i1, int min) {
        alternatetimeoptimalalgo.p[i1].val= min;
    }
    public void receive(int i1,int i3,int min,int max){
        alternatetimeoptimalalgo.p[i1].val= min;
        alternatetimeoptimalalgo.p[i3].val = max;
    }
    public void computation(int i1,int i2,int i3){
        int min = Math.min(Math.min(alternatetimeoptimalalgo.p[i1].val, alternatetimeoptimalalgo.p[i2].val), alternatetimeoptimalalgo.p[i3].val);
        int max = Math.max(Math.max(alternatetimeoptimalalgo.p[i1].val, alternatetimeoptimalalgo.p[i2].val), alternatetimeoptimalalgo.p[i3].val);
        int med = alternatetimeoptimalalgo.p[i1].val + alternatetimeoptimalalgo.p[i2].val + alternatetimeoptimalalgo.p[i3].val - max - min;
        alternatetimeoptimalalgo.p[i1].val = min;
        alternatetimeoptimalalgo.p[i2].val = med;
        alternatetimeoptimalalgo.p[i3].val = max;
    }
    public void run() {
        if (i3== -1) {
            send(i1, i2);
        } else {
            send(i1,i2,i3);
        }
    }
}
public class alternatetimeoptimalalgo {
    static int n=20;
    static pair []p=new pair[n];
    static int flg=0;
    public static void main(String[] args){
        int []arr=new int[n];
        try (Scanner sc = new Scanner(System.in)) 
        {
            System.out.println("Enter "+n+" values to perform time optimal algorithm using"+"<="+"...");
            for(int i=0;i<n;i++){
                arr[i]=sc.nextInt();
                p[i]=new pair();
                p[i].val=arr[i];
                p[i].modval=i%3;
            }
        }
        System.out.println("Round No. "+(0));
        for (int i = 0; i< n; i++) {
            System.out.print(p[i].val + " ModValue= " + p[i].modval +"| ");
        }
        System.out.print("\n");
        for (int i = 0; i < n - 1; i++) {
            flg = 0;
            int threads = 0;
            UsingThread u[] = new UsingThread[n];
            for (int j = 0; j < n; j++) {
                if ((p[j].modval) == 1) {
                    if ((j==0) && (j+1<n)) {
                        u[threads] = new UsingThread(j, j+1,-1);
                        u[threads].start();
                        threads += 1;
                    } else if (j < n - 1) {
                        u[threads] = new UsingThread(j-1, j,j+1);
                        u[threads].start();
                        threads += 1;
                    } else {
                        u[threads] = new UsingThread(j-1,j,-1);
                        u[threads].start();
                        threads += 1;
                    }
                }
            }
            for (int j = 0; j <threads; j++) {
                try {
                    u[j].join();
                } 
                catch (Exception e) {
                    System.out.println("Exception Caught"+e);
                }
            }
            for (int j = 0; j <n; j++) {
                p[j].modval = (p[j].modval + 2) % 3;
            }
            System.out.println("Round No. " + (i+1));
            for (int j = 0; j < n; j++) {
                System.out.print(p[j].val + " ModVal= " + p[j].modval + "|");
            }
            System.out.println();
            System.out.println();
        }
        System.out.println("Final Array is :");
        for (int i = 0; i < n; i++) {
            System.out.print(p[i].val+ "| ");
        }
    }
}
