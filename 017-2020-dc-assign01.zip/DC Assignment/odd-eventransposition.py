from random import randint
from random import shuffle

a=[i for i in range(20)]
shuffle(a)
def printarray(a):
    for i in range(len(a)):
        print(a[i]," | ")

def oddEven(a):
    l=len(a)
    for i in range(l):
        for j in range(i%2,l-1,2):
            if(a[j+1]<a[j]):
                a[j],a[j+1]=a[j+1],a[j]
        print("Array after round ",i)    
        printarray(a);    
    return a

print("array is: ",a)
oddEven(a)
print("Sorted order is: ",a)
